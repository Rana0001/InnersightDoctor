import 'package:flutter/material.dart';

class AppComponents {
  static const defaultBorderRadius = Radius.circular(18);
}
